// the hello world program
document.write('Hello, World!');